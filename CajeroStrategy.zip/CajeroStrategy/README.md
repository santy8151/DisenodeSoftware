# 💳 Cajero con Patrón Strategy — Comisiones por Tipo de Cuenta

> Ejercicio 3 de patrones de diseño — **Strategy**  
> Materia: Diseño de Software | CUN Bogotá

---

## 📌 Descripción

Extensión del cajero automático que aplica el patrón **Strategy** para calcular comisiones bancarias de forma intercambiable según el tipo de cuenta del usuario, sin modificar la clase `Cajero`.

---

## 🎯 Patrón de Diseño Aplicado

### Strategy (Estrategia)

Permite definir una familia de algoritmos (cálculos de comisión), encapsularlos en clases separadas e intercambiarlos en tiempo de ejecución.

| Tipo de cuenta | Comisión |
|---|---|
| Básica | 2% del monto |
| Premium | 0.5% del monto |
| Empresarial | Tarifa fija $3.000 |

```
IEstrategiaComision
       ├── ComisionBasica       → monto × 0.02
       ├── ComisionPremium      → monto × 0.005
       └── ComisionEmpresarial  → $3.000 fijo
```

**Principio clave:** `Cajero` depende de la interfaz `IEstrategiaComision`, no de ninguna implementación concreta → fácil de extender sin modificar código existente (Principio Abierto/Cerrado).

---

## 🗂️ Estructura del Proyecto

```
CajeroStrategy/
└── src/
    ├── App.java                            # Punto de entrada con selección de cuenta
    ├── Interface/
    │   ├── IEstrategiaComision.java        # Interfaz Strategy (calcular + descripcion)
    │   └── ITransaccion.java              # Interfaz Chain of Responsibility
    ├── Strategy/
    │   ├── ComisionBasica.java             # Estrategia concreta: 2%
    │   ├── ComisionPremium.java            # Estrategia concreta: 0.5%
    │   └── ComisionEmpresarial.java        # Estrategia concreta: $3.000 fijo
    ├── Model/
    │   ├── DispensadorBase.java
    │   ├── Dispensador100000.java
    │   ├── Dispensador50000.java
    │   ├── Dispensador20000.java
    │   ├── Dispensador10000.java
    │   ├── Dispensador5000.java
    │   └── Usuario.java
    └── Service/
        └── Cajero.java                     # Usa IEstrategiaComision + cadena de dispensadores
```

---

## ▶️ Cómo compilar y ejecutar

```bash
# Desde la carpeta CajeroStrategy/
javac -d bin -sourcepath src src/App.java
java -cp bin App
```

### Ejemplo de ejecución

```
Ingrese su nombre: Santiago
Ingrese su ID: 001

Seleccione su tipo de cuenta:
  1. Básica      — comisión del 2%
  2. Premium     — comisión del 0.5%
  3. Empresarial — tarifa fija de $3,000
Opción (1/2/3): 1

Ingrese la cantidad a retirar: $200000

╔══════════════════════════════════╗
║       TRANSACCIÓN INICIADA       ║
╚══════════════════════════════════╝
Usuario  : Santiago (ID: 001)
Monto    : $200000
Tipo     : Cuenta Básica (2%)
Comisión : $4000
Total    : $204000

Billetes a entregar:
  Dispensando 2 billete(s) de $100,000

╔══════════════════════════════════╗
║     TRANSACCIÓN COMPLETADA       ║
╚══════════════════════════════════╝
```

---

## 📚 Tarea propuesta

Implementa una cuarta estrategia `ComisionEstudiante` con tarifa fija de $500 y agrégala como opción 4 en `App.java` **sin modificar** ninguna de las clases existentes. Esto demuestra el Principio Abierto/Cerrado (OCP) de SOLID.

---

## 👤 Autor

Estudiante — Diseño de Software  
Corporación Unificada Nacional de Educación Superior (CUN), Bogotá
