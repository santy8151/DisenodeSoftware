package Strategy;

import Interface.IEstrategiaComision;

public class ComisionPremium implements IEstrategiaComision {

    @Override
    public int calcular(int monto) {
        return (int)(monto * 0.005);
    }

    @Override
    public String descripcion() {
        return "Cuenta Premium (0.5%)";
    }
}
