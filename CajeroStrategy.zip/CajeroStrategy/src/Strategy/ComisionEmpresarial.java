package Strategy;

import Interface.IEstrategiaComision;

public class ComisionEmpresarial implements IEstrategiaComision {

    @Override
    public int calcular(int monto) {
        return 3000;
    }

    @Override
    public String descripcion() {
        return "Cuenta Empresarial (tarifa fija $3.000)";
    }
}
