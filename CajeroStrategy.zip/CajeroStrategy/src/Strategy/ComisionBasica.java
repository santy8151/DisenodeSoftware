package Strategy;

import Interface.IEstrategiaComision;

public class ComisionBasica implements IEstrategiaComision {

    @Override
    public int calcular(int monto) {
        return (int)(monto * 0.02);
    }

    @Override
    public String descripcion() {
        return "Cuenta Básica (2%)";
    }
}
