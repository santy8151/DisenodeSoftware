package Interface;

public interface IEstrategiaComision {
    int calcular(int monto);
    String descripcion();
}
