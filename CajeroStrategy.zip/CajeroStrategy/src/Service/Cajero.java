package Service;

import Interface.ITransaccion;
import Interface.IEstrategiaComision;
import Model.*;

public class Cajero {
    private ITransaccion cadenaDispensadores;
    private IEstrategiaComision estrategiaComision;

    public Cajero() {
        configurarCadena();
    }

    private void configurarCadena() {
        Dispensador100000 disp100k = new Dispensador100000();
        Dispensador50000  disp50k  = new Dispensador50000();
        Dispensador20000  disp20k  = new Dispensador20000();
        Dispensador10000  disp10k  = new Dispensador10000();
        Dispensador5000   disp5k   = new Dispensador5000();

        disp100k.setNextHandler(disp50k);
        disp50k.setNextHandler(disp20k);
        disp20k.setNextHandler(disp10k);
        disp10k.setNextHandler(disp5k);

        this.cadenaDispensadores = disp100k;
    }

    // Permite cambiar la estrategia en tiempo de ejecución
    public void setEstrategiaComision(IEstrategiaComision estrategia) {
        this.estrategiaComision = estrategia;
    }

    public void retirarDinero(Usuario usuario, int cantidad) {
        System.out.println("\n╔══════════════════════════════════╗");
        System.out.println("║       TRANSACCIÓN INICIADA       ║");
        System.out.println("╚══════════════════════════════════╝");
        System.out.println("Usuario  : " + usuario.getNombre() + " (ID: " + usuario.getId() + ")");
        System.out.println("Monto    : $" + cantidad);

        // Validaciones
        if (cantidad <= 0) {
            System.out.println("✗ Error: La cantidad debe ser mayor a cero.\n");
            return;
        }
        if (cantidad % 5000 != 0) {
            System.out.println("✗ Error: La cantidad debe ser múltiplo de $5,000.\n");
            return;
        }
        if (estrategiaComision == null) {
            System.out.println("✗ Error: No se ha seleccionado un tipo de cuenta.\n");
            return;
        }

        // Calcular y mostrar comisión
        int comision = estrategiaComision.calcular(cantidad);
        int totalDescontar = cantidad + comision;

        System.out.println("Tipo     : " + estrategiaComision.descripcion());
        System.out.println("Comisión : $" + comision);
        System.out.println("Total    : $" + totalDescontar);
        System.out.println("\nBilletes a entregar:");

        cadenaDispensadores.manejarSolicitud(cantidad);

        System.out.println("\n╔══════════════════════════════════╗");
        System.out.println("║     TRANSACCIÓN COMPLETADA       ║");
        System.out.println("╚══════════════════════════════════╝\n");
    }
}
