import Service.Cajero;
import Model.Usuario;
import Interface.IEstrategiaComision;
import Strategy.ComisionBasica;
import Strategy.ComisionPremium;
import Strategy.ComisionEmpresarial;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Cajero cajero = new Cajero();
        Scanner scanner = new Scanner(System.in);

        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║    SISTEMA DE CAJERO AUTOMÁTICO      ║");
        System.out.println("║       Patrón: Strategy               ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.println("Denominaciones: $100,000 | $50,000 | $20,000 | $10,000 | $5,000");
        System.out.println("Solo se permiten múltiplos de $5,000\n");

        while (true) {
            try {
                System.out.print("Ingrese su nombre (o 'salir' para terminar): ");
                String nombre = scanner.nextLine().trim();

                if ("salir".equalsIgnoreCase(nombre)) {
                    System.out.println("¡Gracias por usar nuestro cajero!");
                    break;
                }

                System.out.print("Ingrese su ID: ");
                String id = scanner.nextLine().trim();

                // Selección de tipo de cuenta (asignación de Strategy)
                System.out.println("\nSeleccione su tipo de cuenta:");
                System.out.println("  1. Básica      — comisión del 2%");
                System.out.println("  2. Premium     — comisión del 0.5%");
                System.out.println("  3. Empresarial — tarifa fija de $3,000");
                System.out.print("Opción (1/2/3): ");
                int opcion = Integer.parseInt(scanner.nextLine().trim());

                IEstrategiaComision estrategia;
                switch (opcion) {
                    case 1: estrategia = new ComisionBasica();      break;
                    case 2: estrategia = new ComisionPremium();     break;
                    case 3: estrategia = new ComisionEmpresarial(); break;
                    default:
                        System.out.println("✗ Opción inválida. Intente de nuevo.\n");
                        continue;
                }

                cajero.setEstrategiaComision(estrategia);

                System.out.print("\nIngrese la cantidad a retirar: $");
                int cantidad = Integer.parseInt(scanner.nextLine().trim());

                Usuario usuario = new Usuario(nombre, id);
                cajero.retirarDinero(usuario, cantidad);

            } catch (NumberFormatException e) {
                System.out.println("✗ Error: Por favor ingrese un número válido.\n");
            } catch (Exception e) {
                System.out.println("✗ Error inesperado: " + e.getMessage() + "\n");
            }
        }

        scanner.close();
    }
}
